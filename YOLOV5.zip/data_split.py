import os
from shutil import copyfile

import pandas as pd

img_path = r"G:\pythonProject\yolov5-6.2\yolov5-master\data\images"
out_path = r"G:\pythonProject\yolov5-6.2\yolov5-master\data_cls\train"
csv = pd.read_csv('ISIC-2017_Training_Part3_GroundTruth.csv')
for row in csv.itertuples():
    pic_name = str(row.image_id) + ".jpg"
    if str(row.melanoma) == "1.0":
        copyfile(os.path.join(img_path, pic_name), os.path.join(out_path, "melanoma", pic_name))
    elif str(row.seborrheic_keratosis) == "1.0":
        copyfile(os.path.join(img_path, pic_name), os.path.join(out_path, "seborrheic_keratosis", pic_name))
    else:
        copyfile(os.path.join(img_path, pic_name), os.path.join(out_path, "others", pic_name))

